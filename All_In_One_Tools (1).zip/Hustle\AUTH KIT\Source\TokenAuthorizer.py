import requests, json

apilink = json.load(open("config.json" , "r+"))['AUTHORIZER-API-LINK']
def TokenToAuthBot():
  AccountNo = 0
  with open('Token.txt', encoding="utf-8") as file:
    while lines := file.readline():
      Token = lines.rstrip()
      AccountNo += 1
      try:
        Req = requests.post(
          apilink,
            headers={"Authorization": Token},
            json={
              "permissions": "0",
              "authorize": True
            })
        if Req.status_code == 200:
          requests.get(
            json.loads(Req.text)['location'],
            headers={
              "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
            })
      except:
         pass
      print(f"[{AccountNo}][{str(Req.status_code)}] : {Token}")

