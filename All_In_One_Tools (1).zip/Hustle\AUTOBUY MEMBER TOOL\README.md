Kindly join discord.gg/leonshop for setup help

Redirects:

1. For the config.json this  http://your_rdp_ip:1337
2. For the main bot this  http://your_rdp_ip:1337/nig
3. For the online members(sellix) this  http://your_rdp_ip:1337/onlinemembers
4. For the offline members(sellix) this  http://your_rdp_ip:1337/offlinemembers