import json
import requests

CLIENTID = json.load(open("config.json", "r+"))['CLIENTID']
CLIENTSECRET = json.load(open("config.json", "r+"))['CLIENTSECRET']
REDIRECTURI = json.load(open("config.json", "r+"))['REDIRECTURI']
AUTHDICT = []


def TokenAuth(Token, AccountNo):
  global AUTHDICT
  try:
    Req = requests.post(
      f"https://discord.com/api/v9/oauth2/authorize?client_id={CLIENTID}&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%3A5000%2Fcallback&scope=identify%20guilds%20guilds.join%20connections%20guilds.members.read%20role_connections.write",
      headers={"Authorization": Token},
      json={
        "permissions": "0",
        "authorize": True
      })
    if Req.status_code != 200:
      print(f"[INVALID] : {Req.json()['message']}")
      return
    r = requests.post(
      'https://discord.com/api/v9/oauth2/token',
      data={
        'client_id': CLIENTID,
        'client_secret': CLIENTSECRET,
        'grant_type': 'authorization_code',
        'code': json.loads(Req.text)['location'].split("=")[1],
        'redirect_uri': REDIRECTURI
      },
      headers={'Content-Type': 'application/x-www-form-urlencoded'})
    r.raise_for_status()
    R = r.json()
  except:
    TokenAuth(Token, AccountNo)
  memberid = json.loads(
    requests.get("https://discordapp.com/api/v6/users/@me",
                 headers={
                   "Authorization": Token
                 }).text)['id']
  AUTHDICT.append({
    'access_token': R['access_token'],
    'refresh_token': R['refresh_token'],
    'id': memberid,
    'TOKEN': Token
  })
  print(f"{AccountNo} : {R['access_token']}")


def TOKENTOAUTH():
  AccountNo = 1
  with open('Token.txt', encoding="utf-8") as file:
    while lines := file.readline():
      TokenAuth(lines.rstrip(), AccountNo)
      AccountNo += 1
  json.dump(AUTHDICT, open("Auths.json", "w"))
