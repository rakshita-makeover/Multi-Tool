import os, time
import json, requests
from colorama import Fore, Style

os.system("clear")
TOKEN = json.load(open("config.json", "r+"))['TOKEN']
FILEPATH = "Auths.json"
AUTHLIST = []

for Auths in json.load(open(FILEPATH, "r+")):
  AUTHLIST.append(Auths)


def AuthJoiner(Authdict=any, CountNo=int, GUILDID=int):
  try:
    R = requests.put("https://discord.com/api/guilds/{}/members/{}".format(
      GUILDID, Authdict['id']),
                     headers={
                       "Authorization": f"Bot {TOKEN}",
                       "Content-Type": "application/json"
                     },
                     json={"access_token": Authdict['access_token']})
    if R.status_code == 400:
      if (json.loads(
          R.text)['message']) == "This account is currently quarantined.":
        print(
          f"{Fore.LIGHTRED_EX}[!][{CountNo}] QUARANTINED : {Authdict['access_token']}{Style.RESET_ALL}"
        )

    elif R.status_code == 429:
      print(
        f"{Fore.LIGHTRED_EX}[!][{CountNo}] RATELIMIT : {Authdict['access_token']}{Style.RESET_ALL}"
      )
      time.sleep(json.loads(R.text)['retry_after'] / 1000)
      CountNo = AuthJoiner(Authdict, CountNo)

    elif R.status_code == 201 and R.text != "":
      CountNo += 1
      print(
        f"{Fore.LIGHTCYAN_EX}[+][{CountNo}] ADDED : {Authdict['access_token']}{Style.RESET_ALL}"
      )
    elif R.text == "":
      print(
        f"{Fore.LIGHTBLACK_EX}[!][{CountNo}] ALREADY ADDED : {Authdict['access_token']}{Style.RESET_ALL}"
      )
    else:
      print(f"{Fore.LIGHTRED_EX}{R.status_code} : {R.text}{Style.RESET_ALL}")

    return CountNo
  except:
    return CountNo


def AUTHJOINER():
  GUILDID = int(
    input(
      f"{Fore.LIGHTBLACK_EX}ENTER GUILD ID FOR JOINING MEMBERS : {Style.RESET_ALL}"
    ))
  AMOUNT = int(
    input(f"{Fore.LIGHTBLACK_EX}ENTER MEMBERS COUNT : {Style.RESET_ALL}"))
  CountNo = 0
  for Auths in AUTHLIST:
    CountNo = AuthJoiner(Auths, CountNo, GUILDID)
    if CountNo >= AMOUNT:
      break
