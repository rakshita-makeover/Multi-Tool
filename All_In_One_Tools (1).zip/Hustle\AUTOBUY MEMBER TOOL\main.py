import string
import random
import os
import sys
import time
from datetime import datetime
import json
from colorama import Fore , init
import requests
import discord
from discord.ext import commands
from flask import Flask, render_template, request, jsonify
import asyncio
from dhooks import Webhook, Embed
from threading import Thread, Lock
import time
import psutil
import platform

# file settings
key_file = 'keys.json'
config_file = 'config.json'

# json settings
config = json.load(open(config_file, 'r'))
main_token = config['Main']['token']
main_prefix = config['Main']['prefix']
allowed_ids = config['Main']['allowed_ids']
online_client_id = config['Delivery']['online']['client_id']
online_token = config['Delivery']['online']['token']
offline_client_id = config['Delivery']['offline']['client_id']
offline_token = config['Delivery']['offline']['token']
redirect = config['Redirect']
owner_name = config['Owner']['Name']
owner_discord = config['Owner']['Discord']
owner_litecoin = config['Owner']['Litecoin']
transcations_webhook = config['Webhooks']['Transcations']
logs_webhook = config['Webhooks']['Logs']
errors_webhook = config['Webhooks']['Errors']
discord_server_url = config['Discord']['url']
client = commands.Bot(command_prefix=[main_prefix , '$'], intents=discord.Intents.all())
client.remove_command('help')
order_webhook  = config['Webhooks']['Orders']
now = datetime.now()
d1 = now.strftime("%H:%M:%S")
sniped_messages = {}  # Dictionary to store deleted messages

init()

class Log:
    lock = Lock()
    log_file = None 
    @staticmethod
    def set_log_file(filename):
        Log.log_file = open(filename, 'a')

    @staticmethod
    def _log(level, prefix, message):
        timestamp = datetime.fromtimestamp(time.time()).strftime("%H:%M:%S")
        log_message = f"[{Fore.LIGHTBLACK_EX}{timestamp}{Fore.RESET}] {prefix} {message}"

        with Log.lock:
            if Log.log_file:
                Log.log_file.write(log_message + '\n')
                Log.log_file.flush()
            print(log_message)

    @staticmethod
    def Success(message, prefix="(+)", color=Fore.LIGHTGREEN_EX):
        Log._log("SUCCESS", f"{color}{prefix}{Fore.RESET}", message)

    @staticmethod
    def Error(message, prefix="(-)", color=Fore.LIGHTRED_EX):
        Log._log("ERROR", f"{color}{prefix}{Fore.RESET}", message)

    @staticmethod
    def Debug(message, prefix="(*)", color=Fore.LIGHTYELLOW_EX):
        Log._log("DEBUG", f"{color}{prefix}{Fore.RESET}", message)

    @staticmethod
    def Info(message, prefix="(?)" , color=Fore.LIGHTWHITE_EX):
        Log._log("INFO", f"{color}{prefix}{Fore.RESET}", message)

    @staticmethod
    def Warning(message, prefix="(!)", color=Fore.LIGHTMAGENTA_EX):
        Log._log("WARNING", f"{color}{prefix}{Fore.RESET}", message)

    @staticmethod
    def info(message, prefix="(?)" , color=Fore.LIGHTWHITE_EX):
        Log._log("INFO", f"{color}{prefix}{Fore.RESET}", message)
    
    @staticmethod
    def error(message, prefix="(-)", color=Fore.LIGHTRED_EX):
        Log._log("ERROR", f"{color}{prefix}{Fore.RESET}", message)

    @staticmethod
    def warning(message, prefix="(!)", color=Fore.LIGHTMAGENTA_EX):
        Log._log("WARNING", f"{color}{prefix}{Fore.RESET}", message)
    

"""
On ready function so that we can see when the bot is online. I added a feature to Notify when their is a litecoin transaction. This is a feature that I added for my own bot. You can remove it if you want.
"""

@client.event
async def on_ready():
    os.system('cls' if os.name == 'nt' else 'clear')
    Log.info(f"Logged in as {client.user.name}#{client.user.discriminator}")
    Log.info(f"Connected to {len(client.guilds)} servers")
    api_url = f'https://api.blockcypher.com/v1/ltc/main/addrs/{owner_litecoin}/full'
    processed_transactions = []
    usdvalue = requests.get('https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd').json() 
    usd_val = usdvalue['litecoin']['usd'] if 'litecoin' in usdvalue else 64.17
    response = requests.get(api_url).json()
    if 'txs' in response:
        transactions = response['txs']
        for transaction in transactions:
            processed_transactions.append(transaction['hash'])
    Log.info(f"Found {len(processed_transactions)} transactions | Connected to Litecoin Address: {owner_litecoin}")
    while True:
        try:
            response = requests.get(api_url).json()
            if 'txs' in response:
                transactions = response['txs']
                for transaction in transactions:
                    transaction_id = transaction['hash']
                    if transaction_id not in processed_transactions:
                        total_usd = transaction['total'] * usd_val / 10**8
                        total_ltc = transaction['total'] / 10**8
                        trans_url = f"https://live.blockcypher.com/ltc/tx/{transaction_id}"
                        embed = Embed(
                            description=f"**New Transaction**\n\n**Amount:** {total_ltc} LTC\n**Value:** ${total_usd}\n**Transaction ID:** {transaction_id}\n**Transaction Url** : {trans_url}\n",
                            color=00000,
                            timestamp='now')
                        
                        transaction_ryan = Webhook(transcations_webhook)
                        transaction_ryan.send(embed=embed)
                        processed_transactions.append(transaction_id)
                        Log.info(f"New Transaction | Amount: {total_ltc} LTC | Value: ${total_usd} | Transaction ID: {transaction_id}")
        
        except Exception as e:
            Log.error(f"Error: {e}")
            pass # ignore errors

        await asyncio.sleep(60)

"""
This is the code part where it will handle erros. It will then Log the errors to console and reply to the user with an embed.
"""
@client.event
async def on_command_error(ctx, error):
    Log.Debug(f"Error: {error} | Command: {ctx.command} | Message: {ctx.message.content} | Author: {ctx.author}")    
    error_responses = {
        commands.CommandNotFound: None,
        commands.MissingRequiredArgument: None,
        commands.MissingPermissions: "You don't have permission to use this command.",
        commands.BotMissingPermissions: "I don't have permission to do this.",
        commands.NotOwner: "You are not the owner of this bot.",
        commands.MissingRole: "You don't have the required role to use this command."
    }
    if isinstance(error, commands.CommandNotFound):
        return
    
    try:
        response = error_responses.get(type(error))
    except:
        response = None
    try:
        if response:
            em = discord.Embed(title="Error", description=response, color=0xff0000)
            await ctx.send(embed=em)

        else:
            em = discord.Embed(title="Error", description=f"An error occurred: {error}", color=0xff0000)
            await ctx.send(embed=em)
    except Exception as e:
        Log.error(f"Error: {e}")
        pass

class Utils:
    def url_(type ,keyyy, client_id):
        """
        This will just return the url of adding a bot with type of online or offline.
        """
        type = type.lower() # This will make sure that the type is lowercase.
        if type == 'online':
            return f"https://discord.com/api/oauth2/authorize?client_id={client_id}&permissions=1&redirect_uri={redirect}/nig&response_type=code&scope=identify%20bot&state={keyyy}"
        elif type == 'offline':
            return f"https://discord.com/api/oauth2/authorize?client_id={client_id}&permissions=1&redirect_uri={redirect}/nig&response_type=code&scope=identify%20bot&state={keyyy}"
        else:
            return None
        
    
class Key:
    """
    This will generate a key and save it to the json file, along with Use and other Info.Not much of a biggie and average code
    
    """
    def generate(_type_, _amount_: int, _start_: int):
        key_length = 8
        key = ''.join(random.choices(string.ascii_letters + string.digits, k=key_length))
        uses_ = 0
        used_info = {
            'status': 'False',
            'time': None,
            'ip': None,
            'user_agent': None,
            'guild_id': None,
        }
        
        key_info = {
            key: {
                'uses': uses_,
                'amount': _amount_,
                'type': _type_,
                'start': _start_,
                'created': str(datetime.now()),
                'used': used_info
            }
        }
        
        with open(key_file, 'r+') as f:
            data = json.load(f)
            data.update(key_info)
            f.seek(0)
            json.dump(data, f, indent=4)
        
        if _type_ == 'online':
            client_id_ = online_client_id
        elif _type_ == 'offline':
            client_id_ = offline_client_id
        else:
            client_id_ = None # This will make sure that the client id is none if the type is not online or offline.
        
        urlll = Utils.url_(_type_, key, client_id_)
        return key, urlll

    @staticmethod
    def check(key):
        with open(key_file, 'r') as f:
            data = json.load(f)
            if key in data:
                key_data = data[key]
                uses = key_data['uses']
                used_info = key_data['used']
                if uses >= 1: # If the key has been used atleast once then it will return the info of the key, as used and shit
                    return False, {
                        'uses': uses,
                        'amount': key_data['amount'],
                        'type': key_data['type'],
                        'start': key_data['start'],
                        'created': key_data['created'],
                        'used': used_info['status'],
                        'used_time': used_info['time'],
                        'used_ip': used_info['ip'],
                        'used_user_agent': used_info['user_agent'],
                        'used_guild_id': used_info['guild_id']
                    }
                elif uses == 0:
                    return True, {
                        'uses': uses,
                        'amount': key_data['amount'],
                        'type': key_data['type'],
                        'start': key_data['start'],
                        'created': key_data['created'],
                        'used': used_info['status']
                    }
            else:
                return None, "Key not found"

    @staticmethod
    def delete(key):
        with open(key_file, 'r+') as f:
            data = json.load(f)
            try:
                if key in data:
                    del data[key]
                    f.seek(0)
                    json.dump(data, f, indent=4)
                    return True
                else:
                    return False
            except Exception as e:
                Log.error(f"Error: {e}")
                return False

    @staticmethod
    def use(key, ip, user_agent, guild_id):
        with open(key_file, 'r+') as f:
            data = json.load(f)
            if key in data:
                key_data = data[key]
                key_data['uses'] += 1
                used_info = key_data['used']
                used_info['status'] = 'True'
                used_info['time'] = str(datetime.now())
                used_info['ip'] = ip if ip is not None else 'Unknown'
                used_info['user_agent'] = user_agent if user_agent is not None else 'Unknown'
                used_info['guild_id'] = guild_id if guild_id is not None else 'Unknown'
                f.seek(0)
                json.dump(data, f, indent=4)
                return True
            else:
                return False

class Files:
    """
    This is the part i hate the most, but i have to do it. This will handle all the file stuff, like creating a file, deleting a file, etc.
    This code is not that good, but it works, so i am not gonna change it.
    """
    def remove_tracking(guild_id): # remove guild from tracking
        with open("guilds/running.txt", "r") as f:
            ok = f.readlines()

        with open("guilds/running.txt", "w") as f:
            for i in ok:
                if i.strip() != str(guild_id):
                    f.write(i)

        file_paths = [f"guilds/{guild_id}.txt", f"guilds/{guild_id}-total.txt"]
        for file_path in file_paths:
            try:
                os.remove(file_path)
            except OSError:
                pass

    def add_tracking(guild_id): # add guild to tracking
        with open("guilds/running.txt", "a") as f:
            f.write(f"{guild_id}\n")

    def get_tracking(): # get all guilds being tracked
        with open("guilds/running.txt", "r") as f:
            return f.readlines()
    
    def get_guilds():
        guilds = []
        for file in os.listdir("guilds"):
            if file.endswith(".txt") and file != "running.txt":
                guilds.append(file.split(".")[0])
        return guilds
        
    def update_join_count(guild_id): # update join count
        filename = f"guilds/{guild_id}.txt"
        try:
            with open(filename, "r") as f:
                count = int(f.read())
        except FileNotFoundError:
            with open(filename, "w") as f:
                count = 0
                f.write(str(count))
                f.close()

        count += 1 # update count

        with open(filename, "w") as f:
            f.write(str(count))
            f.close()
        return count
    
    def remove_auth(key_type, id):
        try:
            if key_type == "online":
                filename = "stocks/online.txt"
            elif key_type == "offline":
                filename = "stocks/offline.txt"
            else:
                raise ValueError("Unknown key type")

            with open(filename, "r") as file:
                lines = file.readlines()

            with open(filename, "w") as file:
                for line in lines:
                    if id not in line:
                        file.write(line)

            Log.info(f"Removed {id} from {key_type} list")
        except FileNotFoundError:
            Log.error(f"Could not find {filename}")
        except Exception as e:
            Log.error(f"Error while removing {id} from {key_type} list: {e}")

"""
This will scrape all the members from a guild, and return a list of members.

"""
def get_members(token, guild_id):
    scraped = False
    url = f'https://canary.discord.com/api/v9/guilds/{guild_id}/members'
    headers = {
        'Authorization': f'Bot {token}'
    }

    members = []
    member_ids = []
    params = {
        'limit': 1000
    }

    while True:
        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 200:
            new_members = json.loads(response.text)
            members.extend(new_members)

            if len(new_members) < 1000:
                scraped = True
                break
            else:
                params['after'] = new_members[-1]['user']['id']
        elif response.status_code == 429:
               if 'retry_after' in response.text:
                    sleep = response.json()['retry_after']
                    Log.warning(f"Rate limited, sleeping for {sleep}ms")
                    time.sleep(sleep)
                    continue
               else:
                    break
        else:
            Log.error(f"Failed to get members for guild {guild_id} with error code {response.status_code}")
            break
    
    if scraped:
        for member in members:
            member_ids.append(member['user']['id'])

        return member_ids
    else:
        return None

"""
Function to Get the current balance of the owner Litecoin address
"""
@client.command(aliases=['bal', 'ltcbal'])
async def getbal(ctx, address):
    await ctx.message.delete()
    api_url = f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}/balance"

    try:
        response = requests.get(api_url)
        data = response.json()

        if "balance" in data:
            confirmed_balance = data["balance"] / 10**8  # Convert balance from satoshis to LTC
            unconfirmed_balance = data["unconfirmed_balance"] / 10**8  # Convert unconfirmed balance from satoshis to LTC
            total_received = data["total_received"] / 10**8  # Convert total received from satoshis to LTC
            total_sent = data["total_sent"] / 10**8  # Convert total sent from satoshis to LTC

            # Fetch LTC to USD exchange rate from Coinbase API
            cb_url = "https://api.coinbase.com/v2/exchange-rates?currency=LTC"
            cb_response = requests.get(cb_url)
            cb_data = cb_response.json()

            if "data" in cb_data and "rates" in cb_data["data"] and "USD" in cb_data["data"]["rates"]:
                ltc_usd_rate = float(cb_data["data"]["rates"]["USD"])
                confirmed_balance_usd = round(confirmed_balance * ltc_usd_rate, 2)
                unconfirmed_balance_usd = round(unconfirmed_balance * ltc_usd_rate, 2)
                total_received_usd = round(total_received * ltc_usd_rate, 2)
                total_sent_usd = round(total_sent * ltc_usd_rate, 2)

                embed = discord.Embed(
                    title="LTC Address Balance",
                    description=f"Address: {address}\n"
                    f"Confirmed balance: ${confirmed_balance_usd}\n"
                    f"Unconfirmed balance: ${unconfirmed_balance_usd}\n"
                    f"Total received: ${total_received_usd}\n"
                    f"Total sent: ${total_sent_usd}"
                )

                await ctx.send(embed=embed)
            else:
                embed_usd = discord.Embed(title = "Error", description = f"Unable to fetch the LTC to USD exchange rate")
                await ctx.send(embed=embed_usd)
        else:
            embed_add = discord.Embed(title = "Error", description = f"Unable to retrieve balances for the provided address")
            await ctx.send(embed=embed_add)
    except Exception as e:
        embed_error = discord.Embed(title = "Error", description = f"An error occurred: {str(e)}")
        await ctx.send(embed=embed_error)

    
@client.command()
async def ping(ctx):
    latency = client.latency * 200
    if latency < 50:
        latency_color = 0x00FF00
    elif latency < 150:
        latency_color = 0xFFA500
    else:
        latency_color = 0xFF0000 

    embed = discord.Embed(title="Latency and Ping", color=latency_color)
    embed.add_field(name="Latency", value=f"**{round(latency)}ms**", inline=False)
    embed.add_field(name="WebSocket Ping", value=f"**{round(client.latency * 200)}ms**", inline=False)

    if latency < 50:
        latency_description = "Your connection to Discord is excellent!"
    elif latency < 150:
        latency_description = "Your connection to Discord is okay."
    else:
        latency_description = "Your connection to Discord might be experiencing bad latency."

    embed.description = latency_description

    await ctx.message.delete()
    await ctx.send(embed=embed)

@client.command(aliases=['ltcaddress','litecoin'])
async def ltc(ctx): 
    await ctx.message.delete()
    msg = await ctx.send(f'`{owner_litecoin}`')
    await msg.reply(embed = discord.Embed(title = "Litecoin Address", description = f"You can make any payments to the above litecoin address", color = 00000))

@client.command()
async def vh(ctx, *, vouch):
    await ctx.message.delete()
    msg = await ctx.send(f"`$rep {vouch}`")
    await msg.reply(embed = discord.Embed(title = "Vouch", description = f"Copy and paste this command in <#1153561249251082310> to vouch for me", color = 00000))

@client.command()
async def leave(ctx, type_: str, guild: str):
    if ctx.author.id not in allowed_ids:
        await ctx.send(embed=discord.Embed(title="Unauthorized", description="You are not authorized to use this command.", color=00000))
        return
    
    if type_ not in ["online", "offline"]:
        await ctx.send(embed=discord.Embed(title="Invalid Type", description="You must provide a valid type ('online' or 'offline').", color=00000))
        return
        
    if type_ == "online":
        token = online_token
    else:
        token = offline_token
        
    headers = {
        'Authorization': 'Bot ' + token
    }

    try:
        response = requests.delete(f'https://discord.com/api/v9/users/@me/guilds/{guild}', headers=headers)
        if response.status_code == 204:
            await ctx.send(embed=discord.Embed(title="Left Guild", description=f"Left guild with ID: {guild}", color=00000))
        else:
            await ctx.send(embed=discord.Embed(title="Failed to Leave", description=f"Failed to leave guild with ID: {guild}\nStatus Code: {response.status_code}", color=00000))
    except Exception as e:
        await ctx.send(embed=discord.Embed(title="Failed to Leave", description=f"Failed to leave guild with ID: {guild}\nError: {e}", color=00000))

@client.command()
async def stock(ctx):
    online_tokens = len(open('stocks/online.txt', 'r').readlines())
    offline_tokens = len(open('stocks/offline.txt', 'r').readlines())
    total_tokens = online_tokens + offline_tokens

    embed = discord.Embed(
        title="Members Stock",
        description="Here's the current members stock information:",
        color=0xFFFFFF
    )
    embed.add_field(name="Online Members", value=f"**{online_tokens}**", inline=True)
    embed.add_field(name="Offline Members", value=f"**{offline_tokens}**", inline=True)
    embed.add_field(name="Total Members", value=f"**{total_tokens}**", inline=False)

    url_to_check = f'{redirect}/stock'
    embed.add_field(name="View On Web", value=f"[Click Here]({url_to_check})", inline=False)

    embed.set_footer(text=f'Last Checked: {datetime.now().strftime("%H:%M:%S")} EST')

    await ctx.message.delete()
    await ctx.send(embed=embed)

def get_running_tasks():
    f = open("guilds/running.txt", "r").read().splitlines()
    running_tasks = []
    
    for guild in f:
        total = open(f"guilds/{guild}-total.txt", "r").read()
        try:
            added = open(f"guilds/{guild}.txt", "r").read()
        except FileNotFoundError:
            added = 0
        
        remaining = int(total) - int(added)
        speed_per_minute = 60
        estimated_minutes = int(remaining) / speed_per_minute
        hours = int(estimated_minutes / 60)
        minutes = int(estimated_minutes % 60)
        seconds = int((estimated_minutes % 1) * 60)
        
        if hours > 0:
            estimated_time = f"{hours}h {minutes}m {seconds}s"
        else:
            estimated_time = f"{minutes}m {seconds}s"
        
        added_percent = int((int(added) / int(total)) * 100)
        remaining_percent = int((int(remaining) / int(total)) * 100)
        
        running_task = {
            'guild': guild,
            'added': f"{added}/{total} ({added_percent}%)",
            'remaining': f"{remaining} ({remaining_percent}%)",
            'estimated_time': estimated_time,
        }
        
        running_tasks.append(running_task)
    
    return running_tasks

@client.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def status(ctx, guild_id=None):
    await ctx.message.delete()
    totalrunning = open("guilds/running.txt", "r").read().splitlines()
    total_running= len(totalrunning)

    def statuslink(guildid):
        return f"{redirect}/guild/{guildid}"
    
    msg = await ctx.send("Loading...")
    if guild_id is None:
        running_tasks = get_running_tasks()
        if not running_tasks:
            em = discord.Embed(title="Status", description=f"No Current Tasks", color=00000)
            return await msg.edit(embed=em)
        
        embed = discord.Embed(title=f"{total_running} Running Tasks", color=00000)

        for task in running_tasks:
            guild_idd = task['guild']
            guildtrackurl = statuslink(guild_idd)
            embed.add_field(
                name=f"__**{task['guild']}**__",
                value=f"**Added**: `{task['added']}`| **Remaining**: `{task['remaining']}`\n**ETA**: `{task['estimated_time']}`| **Stats**: [Click Here]({guildtrackurl})",
                inline=False
            )
        await msg.delete()
        await ctx.send(embed=embed)
    
    else:
        running_tasks = get_running_tasks()
        task = next((t for t in running_tasks if t['guild'] == guild_id), None)
        
        if not task:
            em2 = discord.Embed(title="Status", description=f"No Current Task for guild: {guild_id}", color=00000)
            await msg.delete()
            return await ctx.send(embed=em2)
        
        embed = discord.Embed(title=f"Status - {guild_id}", color=00000)
        status_url = statuslink(guild_id)
        embed.add_field(
            name=f"__**{task['guild']}**__",
            value=f"**Added**: `{task['added']}`| **Remaining**: `{task['remaining']}`\n**ETA**: `{task['estimated_time']}`| **Stats**: [Click Here]({status_url})",
            inline=False
        )
        
        await ctx.message.delete()
        await ctx.send(embed=embed)


def add_to_guild(access_token, userID, guild_Id, key_type):
    tkn = offline_token if key_type == 'offline' else online_token
    while True:
        try:
            url = f"https://canary.discord.com/api/v9/guilds/{guild_Id}/members/{userID}"
            botToken = tkn
            data = {
                "access_token": access_token,
            }
            headers = {
                "Authorization": f"Bot {botToken}",
                'Content-Type': 'application/json'
            }
            response = requests.put(url=url, headers=headers, json=data)

            if response.status_code in (200, 201, 204):
                if "joined" not in response.text:
                    Log.warning(f"User {userID} already in {guild_Id}")
                    return "already", None
                c = Files.update_join_count(guild_Id)
                Log.info(f"[{c}] User {userID} added to {guild_Id}")
                return "success", None
            elif response.status_code == 429:
                if 'retry_after' in response.text:
                    sleep_time = response.json().get('retry_after')
                    Log.warning(f"Rate limited, sleeping for {sleep_time}ms")
                    time.sleep(sleep_time)
                    continue
                else:
                    Log.error(f"Rate limit error occurred while adding user {userID} to {guild_Id}")
                    return "error", "Rate limit exceeded"
            elif "missing perm" in response.text.lower():
                Log.error(f"Missing permissions to add user {userID} to {guild_Id}")
                return "error", "Missing permissions"
            elif "banned" in response.text.lower():
                Log.error(f"User {userID} is banned from {guild_Id}")
                return "error", "User is banned"
            elif "unknown guild" in response.text.lower():
                Log.error(f"Unknown guild {guild_Id}")
                return "error", "Unknown guild"
            else:
                Log.Info(response.text)
                Log.error(f"Unknown error occurred while adding user {userID} to {guild_Id}")
                if "verified" in response.text.lower() or "unknown user" in response.text.lower() or "100" in response.text.lower():
                    Files.remove_auth(key_type=key_type, id=userID)
                    Log.error(f"Removed {userID} from {key_type} members")
                return "error", "Unknown error"
        except requests.exceptions.RequestException as e:
            Log.error(f"Request error occurred while adding user {userID} to {guild_Id}: {e}")
            continue
        except Exception as e:
            Log.error(f"Unexpected error occurred while adding user {userID} to {guild_Id}: {e}")
            return "error", "Unexpected error"
        

def joiner(guild_id, key_type, start_from:int, amount:int):
    tken = offline_token if key_type == 'offline' else online_token
    members = get_members(tken, guild_id)
    if members is not None:
        member_count = len(members)
        Log.info(f"Found {member_count} members in {guild_id}")

    with open(f'stocks/{key_type}.txt', 'r') as f:
        total , success , failed , already , line_no = 0 , 0 , 0 , 0 , 0
        webhook_url = logs_webhook
        webhook = Webhook(webhook_url)
        for line in f:
            line_no +=1
            if line_no < start_from:
                continue

            if success >= amount:
                Files.remove_tracking(guild_id)
                break
            total += 1

            try:
                user_id, access_token, re = line.strip().split(':')
            except:
                Log.error(f"Line : __{line_no}__ |Failed to split line {line_no} in {key_type}.txt | Content : {line.strip()}")
                failed += 1
                continue

            if members is not None:
                if user_id in members:
                    Log.warning(f"Line : __{line_no}__ | User {user_id} already in {guild_id} | skipping")
                    already += 1
                    continue
                
            ok, error = add_to_guild(access_token, user_id, guild_id, key_type)
            if ok == "success":
                success += 1
                Log.info(f"Line : __{line_no}__ | [{success}] User {user_id} added to {guild_id}")
            elif ok == "already":
                already += 1
                Log.info(f"Line :__{line_no}__ | [{already}] User {user_id} already in {guild_id}")
            elif ok == "error":
                if error == "Rate limit exceeded":
                    Log.warning(f"Line :__{line_no}__ | Rate limit exceeded while adding user {user_id} to {guild_id}")
                else:
                    Log.error(f"Line : __{line_no}__  | Failed to add user {user_id} to {guild_id}: {error}")
                    if error in ("Missing permissions", "User is banned", "Unknown guild"):
                        Files.remove_tracking(guild_id)
                        break
                failed += 1
                continue
            else:
                Log.error(f"Line :__{line_no}__  | Unknown error occurred while adding user {user_id} to {guild_id}")
                failed += 1
                continue
        
    Files.remove_tracking(guild_id)
    try:
        embed = Embed(title="Joiner Statistics", color=000000)
        fulfilstatus = "Success" if success >= amount else "Failed"
        diff = amount - success

        embed.description = f"**Target :** {amount}\n**Guild :** {guild_id}\n**InitialCount: ** {member_count}\n**Type :** {key_type}\n**Attempts :** {total}\n**Added :** {success}\n**Failed:** {failed}\n**Already:** {already}\n**Completed Status :** {fulfilstatus}\n**Missing :** {diff}"
        webhook.send(embed=embed)
    except Exception as e:
        Log.error(f"Failed to send webhook: {e}")

@client.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def redeem(ctx, key=None, server_id=None):
    await ctx.message.delete()
    if key == None or server_id == None:
        return await ctx.send(embed = discord.Embed(title = "Invalid Arguments", description = "It should be like: $redeem key serverid", color = 00000))
    url = f"http://127.0.0.1:1337/nig?code=ded&state={key}&guild_id={server_id}&permissions=1"
    s= Key.check(key)
    if s[0] == None:
        await ctx.send(embed = discord.Embed(title = "Key not Found", description = "You must provide a Valid Key", color = 00000))
    elif s[0] == False:
        await ctx.send(embed = discord.Embed(title = "This Key was already Used", description = f"This key was already used for more info visit\n{redirect}/check/{key}", color = 00000))
    else:
        r  = requests.get(url)
        em = discord.Embed(description=f"{r.json()}", color=00000)
        return await ctx.send(embed=em)
    
app = Flask(__name__)

@app.route('/')
def home():
    current_time = datetime.now().strftime("%H:%M:%S")
    return render_template('dashboard.html', owner_id = owner_discord , discord_server_url = discord_server_url,current_time = current_time)

@app.route('/check/<key>')
def check_key(key):
    result, data = Key.check(key)
    return render_template('check_key.html', result=result, data=data, key=key)


@app.route('/buy')
def buy():
    return render_template('buy.html')

@app.route('/guild/<guild_id>')
def guild(guild_id):
    running_tasks = get_running_tasks()
    for task in running_tasks:
        if task['guild'] == guild_id:
            return render_template('guild.html', guild=task)
    
    return render_template('guild.html', guild=None)

@app.route('/stats')
def stats():
    running_tasks = get_running_tasks()
    return render_template('status.html', running_tasks=running_tasks)

@app.route('/litecoin')
def litecoin():
    return render_template('litecoin.html',litecoin_addy=owner_litecoin)

@app.route('/stock')
def stock():
    online_tokens = len(open("stocks/online.txt").readlines())
    offline_tokens = len(open("stocks/offline.txt").readlines())
    return render_template('stock.html',online_tokens=online_tokens,offline_tokens=offline_tokens)

def generate_offline(amount):
    k , i = Key.generate(_type_ = 'offline', _amount_ = amount, _start_ = 0)
    Log.info(f"Generated {k} key | Url : {i}")
    try:
        web = Webhook(order_webhook)
        em = Embed(title="New Offline Members Order Recieved", color=00000)
        em.add_field(name="Quantity", value=amount, inline=False)
        em.add_field(name="Key", value=k, inline=False)
        web.send(embed=em)
    except Exception as e:
        Log.error(f"Failed to send webhook: {e}")
        pass
    message = f"Key: {k}\nBot Link: {i}\n\nThanks for purchasing! Add the bot you just received, and joining will start automatically. If joining didn't start, you can use the $redeem command in our support server: {discord_server_url} to trigger the joiner.\nYou can track your order using the $status command in the support server as well."
    try:
        web = Webhook(order_webhook)
        web.send(message)
    except Exception as e:
        Log.error(f"Failed to send webhook: {e}")
        pass
    return k, i, message


def generate_online(amount):
    k, i = Key.generate(_type_ = 'online', _amount_ = amount, _start_ = 0)
    Log.info(f"Generated {k} key | Url : {i}")
    try:
        web = Webhook(order_webhook)
        em = Embed(title="New Online Members Order Recieved", color=00000)
        em.add_field(name="Quantity", value=amount, inline=False)
        em.add_field(name="Key", value=k, inline=False)
        web.send(embed=em)
    except Exception as e:
        Log.error(f"Failed to send webhook: {e}")
        pass
    message = f"Key: {k}\nBot Link: {i}\n\nThanks for purchasing! Add the bot you just received, and joining will start automatically. If joining didn't start, you can use the $redeem command in our support server: {discord_server_url} to trigger the joiner.\nYou can track your order using the $status command in the support server as well."
    try:
        web = Webhook(order_webhook)
        web.send(message)
    except Exception as e:
        Log.error(f"Failed to send webhook: {e}")
        pass
    return k, i, message


@app.route('/offlinemembers', methods=['POST', 'GET'])
def sellix_webhook():
    jsonx = request.get_json()
    data = jsonx['data']
    quantity = data['quantity']
    key,url,product = generate_offline(quantity)
    Log.info(f"Sent : {product}")
    return product


@app.route('/onlinemembers', methods=['POST', 'GET'])
def sellix_webhookk():
    jsonx = request.get_json()
    data = jsonx['data']
    quantity = data['quantity']
    key,url,product = generate_online(quantity)
    Log.info(f"Sent : {product}")
    return product

hook = Webhook(logs_webhook)

@app.route('/nig')
def callback():
    try:
        code = request.args.get('code')
        if code is None:
            return jsonify({'error': 'No code provided'}), 400
        guild_id = request.args.get('guild_id')
        if guild_id is None:
            return jsonify({'error': 'No guild_id provided'}), 400
        key = request.args.get('state')
        if key is None:
            return jsonify({'error': 'No key provided'}), 400
    except Exception as e:
        return jsonify({'error': 'Invalid request parameters'}), 400
    
    ip = request.remote_addr
    ua = request.headers.get('User-Agent')

    with open('keys.json', 'r') as f:
        keys_data = json.load(f)

    key_data = keys_data.get(key)
    if key_data is None:
        em = Embed(description=f"Invalid key use attempt\nIP: {ip}\nUA: {ua}\nKey: {key}\nGuild: {guild_id}", color=00000)
        hook.send(embed=em)
        return jsonify({'error': 'Invalid key'}), 401
    
    uses_times = key_data['uses']
    key_type = key_data['type']
    tkn = offline_token if key_type == 'offline' else online_token
    headers = {"Authorization": f"Bot {tkn}"}

    if uses_times > 0:
        em = Embed(description=f"Key has no uses remaining\nIP: {ip}\nUA: {ua}\nKey: {key}\nGuild: {guild_id}", color=00000)
        hook.send(embed=em)
        return jsonify({'error': 'Key already redeemed or has no uses remaining'}), 409

    f = open("guilds/running.txt", "r").read().splitlines()
    if guild_id in f:
        em = Embed(description=f"This guild already has a running task.\nIP: {ip}\nUA: {ua}\nKey: {key}\nGuild: {guild_id}", color=00000)
        hook.send(embed=em)
        return jsonify({'error': 'This guild already has a running task, let it complete before initiating a new one.'}), 409

    r = requests.get(f"https://canary.discord.com/api/v9/guilds/{guild_id}", headers=headers)
    if "unknown guild" in r.text.lower() and guild_id not in r.text.lower():
        return jsonify({'error': 'Bot removed from server'}), 400
    
    key_data['uses'] += 1
    key_data['used']['status'] = "True"
    key_data['used']['time'] = str(datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
    key_data['used']['ip'] = ip
    key_data['used']['user_agent'] = ua
    key_data['used']['guild_id'] = guild_id
    
    with open('keys.json', 'w') as f:
        json.dump(keys_data, f, indent=4)

    key_type = key_data['type']
    amount = key_data['amount']
    start_from = key_data['start']


    try:
        Thread(target=joiner, args=(guild_id, key_type, start_from, amount)).start()
        uses_times -= 1

        with open("guilds/running.txt", "a") as f:
            f.write(f"{guild_id}\n")

        with open(f"guilds/{guild_id}-total.txt", "a") as f2:
            f2.write(str(amount))

        em = Embed(description=f"Key used\nIP: {ip}\nUA: {ua}\nKey: {key}\nKey Type: {key_type}\nGuild: {guild_id}", color=00000)
        hook.send(embed=em)

        return jsonify({'success': 'Key successfully used','info':{
            'key': key,
            'key_type': key_type,
            'guild_id': guild_id,
            'uses_remaining': uses_times,
            'amount': amount,
            'start_from': start_from,
            'Track Url':f"{redirect}/guild/{guild_id}"
        }}
        ), 200
    except Exception as e:
        hook.send(f"Error occurred while adding guild {guild_id} - {e}")
        return jsonify({'error': 'Invalid guild'}), 400

@client.command()
async def key(ctx, _type_ : str, _start_ : int, _amount_ : int):
    if ctx.author.id not in allowed_ids:
        await ctx.send(embed = discord.Embed(title = "Invalid Permissions", description = "You do not have permission to use this command", color = 00000))
        return 
    
    if ctx.author.id in allowed_ids:
        _type_ = _type_.lower()
        if _type_ == 'online':
            _type_ = 'online'
            embed_image = 'https://cdn.discordapp.com/attachments/1153561249481756718/1166390366388359188/logo.jpg?ex=6566002d&is=65538b2d&hm=354385ee7c57253b1f0050afae23115715a56ee0cffe5d0d8ad20bd55765b75c&'
        elif _type_ == 'offline':
            _type_ = 'offline'
            embed_image = 'https://cdn.discordapp.com/attachments/1153561249481756718/1166390366388359188/logo.jpg?ex=6566002d&is=65538b2d&hm=354385ee7c57253b1f0050afae23115715a56ee0cffe5d0d8ad20bd55765b75c&'
        else:
            await ctx.send(embed = discord.Embed(title = "Invalid type", description = "Type must be either `online` or `offline`", color = 00000))
            return
    keyyy,urll = Key.generate(_type_, _amount_, _start_)
    embed = discord.Embed(title = "Key Generated", description =f"**Key:** {keyyy}\n**Type:** {_type_}\n**Amount:** {_amount_}\n**Start:** {_start_}\n**URL:** [Click Here]({urll})\n\n```It will start automatically as soon as you add the bot, if didn't start make sure the bot is in server and send command $redeem```", color = 00000)
    embed.set_thumbnail(url = embed_image)
    await ctx.message.delete()
    await ctx.send(embed = embed)

@client.command()
async def checkkey(ctx, key_: str = None):
    if key_ is None:
        await ctx.send(embed=discord.Embed(title="Invalid Key", description="Please provide a key to check", color=0x000000))
        return

    if 'https://discord.com/' in key_:
        key_ = key_.split('&state=')[1]
    else:
        key_ = key_.strip()

    result, details = Key.check(key_)
    url = f"{redirect}/check/{key_}"

    if result is False:
        status = "Used Key"
    elif result is True:
        status = "Valid Key"
    else:
        await ctx.send(embed=discord.Embed(title="Invalid Key", description=f"**Key:** {key_}\n**Error:** {details}", color=0x000000))
        return

    embed = discord.Embed(
        title=status,
        description=f"**Key:** {key_}\n**Type:** {details['type']}\n**Amount:** {details['amount']}\n"
                    f"**Start:** {details['start']}\n**Created:** {details['created']}\n**Used:** {details['used']}",
        color=0x000000
    )
    if result is False:
        embed.add_field(name="Used Time", value=details['used_time'])
        embed.add_field(name="Used User Agent", value=details.get('used_user_agent', 'N/A'))
        embed.add_field(name="Used Guild ID", value=details.get('used_guild_id', 'N/A'))

    embed.add_field(name="More Info", value=f"[Click Here]({url})")
    await ctx.send(embed=embed)


@client.command()
async def guildhistory(ctx, guild_id : int = None):
    tota_amount = 0
    if guild_id is None:
        await ctx.send(embed = discord.Embed(title = "Invalid Guild ID", description = "Please provide a guild ID to check", color = 00000))
        return
    try:
        with open('keys.json') as f:
            keys_data = json.load(f)
    except Exception as e:
        Log.Error(f"Error occurred while fetching data - {e}")
        await ctx.send(embed = discord.Embed(title = "Error", description = "An error occurred while fetching data", color = 00000))
        return
    try:
        guild_id = int(guild_id)
    except:
        await ctx.send(embed = discord.Embed(title = "Invalid Guild ID", description = "Please provide a valid guild ID to check", color = 00000))
        return
    
    for key in keys_data:
        if keys_data[key]['used']['guild_id'] == str(guild_id):
            tota_amount += keys_data[key]['amount']
    embed = discord.Embed(title = "Guild History", description = f"**Guild ID:** {guild_id}\n**Total Amount:** {tota_amount}", color = 00000)
    await ctx.message.delete()
    await ctx.send(embed = embed)
    return


@client.command()
async def statistics(ctx):
    cpu_usage = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    memory_usage = memory.percent
    latency = round(client.latency * 1000) 
    bot_info = f"Bot Version: {discord.__version__}\nPython Version: {platform.python_version()}"
    embed = discord.Embed(title="Info", color=00000)
    embed.add_field(name="Bot Information", value=bot_info, inline=False)
    embed.add_field(name="CPU Usage", value=f"{cpu_usage:.2f}%")
    embed.add_field(name="Memory Usage", value=f"{memory_usage:.2f}%")
    embed.add_field(name="Latency", value=f"{latency} ms")
    await ctx.message.delete()
    await ctx.send(embed=embed)


@client.command()
async def help(ctx):
    embed = discord.Embed(
        title="Help",
        description=f"**Prefix:** $  **Total Commands:** 23\n\n**Commands and Descriptions**\n`$help` - Shows this help menu\n`$statistics` - Shows bot statistics\n`$getbal` - Shows user balance\n`$ping` - Shows bot latency\n`$ltc` - Gives Litecoin address\n`$binance` - Gives binnance mail\n`$vh` - Gives vouch statement\n`$leave` - Leaves server\n`$stock` - Shows stock\n`$status` - Shows order status\n`$redeem` - Redeems key\n`$key` - Generates key\n`$checkkey` - Checks key\n`$guildhistory` - Shows previous orders of a guild\n`$revoke` - Revokes key\n`$nuke` - Nukes a Channel\n`$purge` - Delete message\n`$rep` - Vouch the owner\n`$ban` - Ban a person\n`$calc` - Calculator\n`$cl` - Gives client role\n`$snipe` - Snipes deleted message\n`$ltcprice` - Gives latest ltc price",
        color=0x000000
    )
    
    await ctx.message.delete()
    await ctx.send(embed=embed)

@client.command()
async def calc(ctx, *, expression):
    if ctx.author.id != 1155407031004577833:
        return await ctx.send("Unauthorized")
    # print(expression)
    print(ctx.author)
    sol = eval(expression)
    em = discord.Embed(title="Calculator", description=f"**Question**\n```arm\n{expression}```\n\n**Answer**\n```arm\n{sol}```", color=00000)
    await ctx.message.delete()
    await ctx.send(embed=em)

@client.command()
async def rep(ctx, *, rep):
    user = ctx.message.author
    embed_image = 'https://cdn.discordapp.com/attachments/1153561249481756718/1166390366388359188/logo.jpg?ex=6566002d&is=65538b2d&hm=354385ee7c57253b1f0050afae23115715a56ee0cffe5d0d8ad20bd55765b75c&'
    embed = discord.Embed(title = "New vouch created!", description = f"**Vouch:**\n {rep}\n\n**Vouch by:** {user.mention}\n*Thanks for vouching us*", color = 00000)
    embed.set_thumbnail(url = embed_image)
    await ctx.message.delete()
    await ctx.send(embed=embed)

@client.command()
async def cl(ctx, member: discord.Member):
    embed_success = discord.Embed(title = "Client", description = f"{member.mention} has been given the <@&1162202234159898784> role")
    embed_error = discord.Embed(title = "Client", description = f"Role doesn't exist")
    embed_perm = discord.Embed(title = "Client", description = f"You don't have permission to use this command")
    if ctx.message.author.guild_permissions.manage_roles:
        client_role = discord.utils.get(ctx.guild.roles, name="CLIENT")
        if client_role:
            await member.add_roles(client_role)
            await ctx.message.delete()
            await ctx.send(embed=embed_success)
        else:
            await ctx.message.delete()
            await ctx.send(embed=embed_error)
    else:
        await ctx.message.delete()
        await ctx.send(embed=embed_perm)


@client.command()
async def ban(ctx, member: discord.Member, *, reason=None):
    embed_ban = discord.Embed(title = "Ban", description = f"{member.mention} **has been banned from the server**\n**Reason:** {reason}")
    embed_fail = discord.Embed(title = "Ban", description = f"You do not have the permission to ban members")
    if ctx.author.guild_permissions.ban_members:  # Check if the author has permission to ban members
        await member.ban(reason=reason)
        await ctx.message.delete()
        await ctx.send(embed=embed_ban)
    else:
        await ctx.message.delete()
        await ctx.send(embed=embed_fail)


@client.command()
async def nuke(ctx):
        embed_perm = discord.Embed(title = "Nuke", description = f"You do not have the permission to nuke")
        if ctx.author.id != 1155407031004577833:
            return await ctx.send(embed=embed_perm)
        embed_nuke = discord.Embed(title = "Nuke", description = f"Channel successfully nuked")
        await ctx.message.delete()
        print(f"{d1} {Fore.GREEN}[+]{Fore.GREEN}{Fore.RESET} Command \"nuke\" used.{Fore.RESET}")
        channel = ctx.channel
        new_channel = await channel.clone()
        await channel.delete()
        await new_channel.edit(position=channel.position)
        await new_channel.send(embed=embed_nuke)


@client.command()
async def purge(ctx, amount : int):
    embed_perm = discord.Embed(title = "Purge", description = f"You do not have the permission to purge")
    if ctx.author.id != 1155407031004577833:
        return await ctx.send(embed=embed_perm)
    embed_purge = discord.Embed(title = "Purge", description = f"Succesfully Purged")
    print(f"{d1} {Fore.GREEN}[+]{Fore.GREEN}{Fore.RESET} Command \"purge\" used.{Fore.RESET}")
    await ctx.channel.purge(limit=amount+1)
    await ctx.send(embed=embed_purge)


@client.event
async def on_message_delete(message):
    if message.guild is not None:
        if message.channel not in sniped_messages:
            sniped_messages[message.channel] = []
        sniped_messages[message.channel].append(message)

@client.command()
async def snipe(ctx, mode='recent'):
    if ctx.channel in sniped_messages:
        if mode == 'recent':
            if sniped_messages[ctx.channel]:
                message = sniped_messages[ctx.channel][-1]
                embed = Embed(
                    title='Most Recent Sniped Message'
                )
                embed.add_field(name=f'Author: {message.author}', value=message.content, inline=False)
                await ctx.message.delete()
                await ctx.send(embed=embed)
            else:
                embed = Embed(
                    title='Error',
                    description='No deleted messages to snipe.'
                )
                await ctx.send(embed=embed)
        elif mode == 'all':
            messages = sniped_messages[ctx.channel]
            if messages:
                snipe_message = ""
                for index, message in enumerate(messages, start=1):
                    snipe_message += f'Sniped message {index}: {message.content} (author: {message.author})\n'
                embed = Embed(
                    title='All Sniped Messages',
                    description=snipe_message
                )
                await ctx.send(embed=embed)
                await ctx.message.delete()
                sniped_messages[ctx.channel] = []  # Clear the list after sending all messages
            else:
                embed = Embed(
                    title='Error',
                    description='No deleted messages to snipe.'
                )
                await ctx.send(embed=embed)
                await ctx.message.delete()
        else:
            embed = Embed(
                title='Error',
                description='Invalid mode. Use `!snipe recent` or `!snipe all`.'
            )
            await ctx.send(embed=embed)
            await ctx.message.delete()
    else:
        embed = Embed(
            title='Error',
            description='No deleted messages to snipe.'
        )
        await ctx.send(embed=embed)
        await ctx.message.delete()


@client.command()
async def ltcprice(ctx):
    await ctx.message.delete()
    print(f"{d1} {Fore.GREEN}[+]{Fore.GREEN}{Fore.RESET} Command \"ltcprice\" used.{Fore.RESET}")
    url = 'https://api.coingecko.com/api/v3/coins/litecoin'
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        price = data['market_data']['current_price']['usd']
        embed_price = discord.Embed(title = "Ltc Price", description = f"The current price of Litecoin is ${price:.2f}")
        await ctx.send(embed=embed_price)
    else:
        embed_error = discord.Embed(title = "Error", description = f"Failed to fetch currnet litecoin price!")
        await ctx.send(embed=embed_error)


@client.command()
async def binance(ctx):
    embed = discord.Embed(title = "Binance", description = f"Mail: SOON\nId: SOON")
    await ctx.message.delete()
    await ctx.send(embed=embed)


@client.command()
async def revoke(ctx, key_: str = None):
    if key_ is None:
        await ctx.send(embed=discord.Embed(title="Invalid Key", description="Please provide a key to revoke", color=0x000000))
        return
    if ctx.author.id not in allowed_ids:
        await ctx.send(embed = discord.Embed(title = "Invalid Permissions", description = "You do not have permission to use this command", color = 00000))
        return
    if 'https://discord.com/' in key_:
        key_ = key_.split('&state=')[1]
    else:
        key_ = key_.strip()
    
    result, details = Key.check(key_)
    url = f"{redirect}/check/{key_}"

    if result is False:
        status = "Used Key"
    elif result is True:
        status = "Valid Key"
    else:
        await ctx.message.delete()
        await ctx.send(embed=discord.Embed(title="Invalid Key", description=f"**Key:** {key_}\n**Error:** {details}", color=0x000000))
        return
    
    if status == "Used Key":
        await ctx.message.delete()
        await ctx.send(embed=discord.Embed(title="Invalid Key", description=f"**Key:** {key_}\n**Error:** Key has already been used", color=0x000000))
        return
    else:
        with open('keys.json') as f:
            keys_data = json.load(f)
        
        if key_ not in keys_data:
            await ctx.message.delete()
            await ctx.send(embed=discord.Embed(title="Invalid Key", description=f"**Key:** {key_}\n**Error:** Key does not exist", color=0x000000))
            return
        else:
            keys_data.pop(key_)
            with open('keys.json', 'w') as f:
                json.dump(keys_data, f, indent=4)
            await ctx.message.delete()    
            await ctx.send(embed=discord.Embed(title="Success", description=f"**Key:** {key_}\n**Status:** Key has been revoked", color=0x000000))
            return
        


def run_bot():
    client.run(main_token)

if __name__ == '__main__':
    from threading import Thread
    thread = Thread(target=app.run, kwargs={'host': '0.0.0.0', 'port': 1337})
    thread.start()
    run_bot()
