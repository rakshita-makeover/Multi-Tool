import discord
from discord.ext import commands
from dhooks import Webhook, Embed
from datetime import datetime
from decouple import config

class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.deleted_log_webhook_url = config('hookurl')

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        logging_enabled = config('deleted_logs', default=False, cast=bool)
        if not logging_enabled:
            return

        if message.author == self.bot.user or message.author.bot:
            return


        server = message.guild.name if message.guild else 'DM'

        log_message = (
            f'- {message.author.name} `({message.author.id})`\n'
            f'- **Server** ~ {server}\n'
            f'- **Message** ~ {message.content}\n\n'
        )

        if message.attachments:
            attachment_urls = [a.url for a in message.attachments]
            image_attachments = [url for url in attachment_urls if url.endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp'))]
            video_attachments = [url for url in attachment_urls if url.endswith(('.mp4', '.mov', '.avi', '.mkv', '.webm'))]

            if image_attachments:
                log_message = f'- **Images** ~ {", ".join(image_attachments)}\n\n'

            if video_attachments:
                log_message = f'- **Videos** ~ {", ".join(video_attachments)}\n\n'

        log_message = (
            f'- **Channel** ~ <#{message.channel.id}>\n'
            f'- **Channel Name** ~ {message.channel.name}'
        )

        embed = Embed(
            title="Deleted Message",
            description=log_message,
            color=0xffffff,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

        thumbnail_url = str(message.author.avatar_url)
        embed.set_thumbnail(url=thumbnail_url)

        deleted_log_webhook = Webhook(url=self.deleted_log_webhook_url)
        deleted_log_webhook.send(embed=embed)

    def setup(self, bot):
        bot.add_cog(self)

def setup(bot):
    deleted_message_logger = Logs(bot)
    deleted_message_logger.setup(bot)