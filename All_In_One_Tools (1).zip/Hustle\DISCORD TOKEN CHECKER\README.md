Simple Discord Token Checker with nice looking output.
Support for unverified, mail verified, phone verified and fully verified tokens.

Can save tokens in different formats. 
- (example: input mail:pass:token and output token:pass)

For more format config the main.py

Example:
FORMAT = 2 # 0 = token, 1 = token:password, 2 = mail:pass:token, 3 = token:mail:pass
OUTPUT = 2 # 0 = token, 1 = token:password, 2 = mail:pass:token, 3 = token:mail:pass