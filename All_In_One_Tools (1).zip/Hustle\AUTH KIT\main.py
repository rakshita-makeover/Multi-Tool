import os, json
from colorama import Fore, Style

print(f"""{Fore.LIGHTMAGENTA_EX}1. Convert Token To Auth 
2. Join Auth To Server
3. Authorize Token To Auth Bot
{Style.RESET_ALL}""")

try:
  json.load(open("Auths.json", "r"))
except:
  json.dump([], open("Auths.json", "w"))

option = int(
  input(f"{Fore.LIGHTBLACK_EX}Enter Your Option : {Style.RESET_ALL}"))
os.system("cls")
if option == 1:
  from Source.TokenToAuth import TOKENTOAUTH
  TOKENTOAUTH()
if option == 2:
  from Source.AuthJoin import AUTHJOINER
  AUTHJOINER()
if option == 3:
  from Source.TokenAuthorizer import TokenToAuthBot
  TokenToAuthBot()
