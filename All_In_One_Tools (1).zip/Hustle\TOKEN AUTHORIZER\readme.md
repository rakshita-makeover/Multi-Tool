# How to use

-> Put tokens in tokens.txt
-> Fill the config.json with details
-> Output folder should already be created
-> You can retry failed tokens if failure is unknown

# Output Formats
-> auths.txt -> userid:access_token:refreshid
-> failed_auths.txt -> token
-> tokens_authed.txt -> token

# Note
Make sure to put correct details etc on the authorizer to get the desired output